import React from 'react'
import Com from './Com'

const NestingCom = () => {
  return (
    <div>
        <Com/>
    </div>
  )
}

export default NestingCom