import React from 'react'

const FormCom = () => {

  function handleSubmit(){
        console.log()
  }

  return (
    <div className='bg-gray-600 p-10 flex justify-around'>
        <form action="">
            <label htmlFor="">Name:</label>
            <input type="text" className='border-2 border-solid border-black mt-5 ml-2' /><br />
            <label htmlFor="">Age:</label>
            <input type="age" className='border-2 border-solid border-black mt-5 ml-2'/><br />
            <label htmlFor="">Graduation:</label>
            <input type="graduation" className='border-2 border-solid border-black mt-5 ml-2'/>
        </form>
    </div>
  )
}

export default FormCom