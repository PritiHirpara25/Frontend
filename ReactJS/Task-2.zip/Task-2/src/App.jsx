import { useState } from 'react'
import './App.css'
import Task from './Task'
import NestingCom from './NestingComponent/NestingCom'
import FormCom from './FormCom'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* <Task/> */}
      {/* <NestingCom/> */}
      <FormCom/>
    </>
  )
}

export default App
