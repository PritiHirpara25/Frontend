import './App.css'
import Layout from './Layout'
// import Navbar from './Navbar'
// import Cart from './ShoppingCart/Cart'
// import Shop from './ShoppingCart/Shop'
import Card from './Theme/Card'
// import ThemeButton from './Theme/ThemeButton'

function App() {

  return (
    <>
      <Layout />
      {/* <Shop /> */}
      {/* <Card /> */}
    </>
  )
}

export default App
