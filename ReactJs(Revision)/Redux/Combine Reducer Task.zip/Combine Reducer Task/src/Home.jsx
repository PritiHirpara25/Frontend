import React from 'react'

const Home = () => {
  return (
    <div>Welcome Home</div>
  )
}

export default Home