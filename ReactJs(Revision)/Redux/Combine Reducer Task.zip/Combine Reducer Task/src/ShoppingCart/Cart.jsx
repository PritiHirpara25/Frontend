import React from 'react'

const Cart = () => {
  return (
    <div>
        <button>CART PAGE</button>
    </div>
  )
}

export default Cart